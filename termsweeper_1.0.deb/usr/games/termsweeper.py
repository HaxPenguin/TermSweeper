import curses
import random

# Board settings
ROWS = 10
COLS = 10
MINES = 10

# Cell states
HIDDEN = 0
REVEALED = 1
FLAGGED = 2

DIRS = [(-1,-1), (-1,0), (-1,1), (0,-1), (0,1), (1,-1), (1,0), (1,1)]

def init_board():
    board = [[0 for _ in range(COLS)] for _ in range(ROWS)]
    states = [[HIDDEN for _ in range(COLS)] for _ in range(ROWS)]
    placed = 0
    while placed < MINES:
        r, c = random.randint(0, ROWS - 1), random.randint(0, COLS - 1)
        if board[r][c] == -1:
            continue
        board[r][c] = -1
        placed += 1
        for dr, dc in DIRS:
            nr, nc = r + dr, c + dc
            if 0 <= nr < ROWS and 0 <= nc < COLS and board[nr][nc] != -1:
                board[nr][nc] += 1
    return board, states

def draw_centered_text(stdscr, lines):
    stdscr.clear()
    h, w = stdscr.getmaxyx()
    for i, line in enumerate(lines):
        y = h // 2 - len(lines) // 2 + i
        x = w // 2 - len(line) // 2
        stdscr.addstr(y, x, line)
    stdscr.refresh()

def draw_board(stdscr, board, states, cursor):
    stdscr.clear()
    h, w = stdscr.getmaxyx()
    board_height = ROWS
    board_width = COLS * 2
    top = (h - board_height) // 2
    left = (w - board_width) // 2

    for r in range(ROWS):
        for c in range(COLS):
            y, x = top + r, left + c * 2
            if cursor == (r, c):
                stdscr.attron(curses.A_REVERSE)
            if states[r][c] == HIDDEN:
                stdscr.addstr(y, x, "#")
            elif states[r][c] == FLAGGED:
                stdscr.addstr(y, x, "F")
            elif board[r][c] == -1:
                stdscr.addstr(y, x, "*")
            elif board[r][c] == 0:
                stdscr.addstr(y, x, " ")
            else:
                stdscr.addstr(y, x, str(board[r][c]))
            if cursor == (r, c):
                stdscr.attroff(curses.A_REVERSE)

    stdscr.addstr(top + ROWS + 2, left, "Arrows: Move   Space: Reveal   F: Flag   Q: Quit")
    stdscr.refresh()

def reveal(board, states, r, c):
    if states[r][c] != HIDDEN:
        return
    states[r][c] = REVEALED
    if board[r][c] == 0:
        for dr, dc in DIRS:
            nr, nc = r + dr, c + dc
            if 0 <= nr < ROWS and 0 <= nc < COLS:
                reveal(board, states, nr, nc)

def show_tutorial(stdscr):
    lines = [
        "How to Play Minesweeper:",
        "",
        "- Move with the arrow keys",
        "- Press SPACE to reveal a cell",
        "- Press F to flag/unflag a cell",
        "- Numbers = how many mines surround a square",
        "- Reveal all safe cells to win",
        "- If you reveal a mine it explodes and you lose a life",
        "",
        "Press any key to return to the main menu..."
    ]
    draw_centered_text(stdscr, lines)
    stdscr.getch()

def game_loop(stdscr):
    board, states = init_board()
    cursor = [0, 0]
    while True:
        draw_board(stdscr, board, states, tuple(cursor))
        key = stdscr.getch()
        if key == curses.KEY_UP and cursor[0] > 0:
            cursor[0] -= 1
        elif key == curses.KEY_DOWN and cursor[0] < ROWS - 1:
            cursor[0] += 1
        elif key == curses.KEY_LEFT and cursor[1] > 0:
            cursor[1] -= 1
        elif key == curses.KEY_RIGHT and cursor[1] < COLS - 1:
            cursor[1] += 1
        elif key == ord(' '):
            r, c = cursor
            if board[r][c] == -1:
                for rr in range(ROWS):
                    for cc in range(COLS):
                        states[rr][cc] = REVEALED
                draw_board(stdscr, board, states, tuple(cursor))
                draw_centered_text(stdscr, [
                    "you lose",
                    "Press any key to return to menu."
                ])
                stdscr.getch()
                break
            reveal(board, states, r, c)
        elif key == ord('f'):
            r, c = cursor
            if states[r][c] == HIDDEN:
                states[r][c] = FLAGGED
            elif states[r][c] == FLAGGED:
                states[r][c] = HIDDEN
        elif key == ord('q'):
            break

def main_menu(stdscr):
    curses.curs_set(0)
    while True:
        draw_centered_text(stdscr, [
            "Terminal Minesweeper",
            "",
            "1. Play Game",
            "2. How to Play",
            "3. Quit"
        ])
        choice = stdscr.getch()
        if choice == ord('1'):
            game_loop(stdscr)
        elif choice == ord('2'):
            show_tutorial(stdscr)
        elif choice == ord('3'):
            break

def run_game():
    curses.wrapper(main_menu)

if __name__ == "__main__":
    run_game()
